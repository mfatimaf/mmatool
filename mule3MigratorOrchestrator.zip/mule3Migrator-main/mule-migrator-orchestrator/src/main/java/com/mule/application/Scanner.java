package com.mule.application;

import com.mule.application.ApplicationMetrics;

public class Scanner {

	public ApplicationMetrics scanMule3Code(ApplicationMetrics am) {

		/*
		 * Logic to scan Mule 3 code and update am object
		 */

		return am;

	}

}
