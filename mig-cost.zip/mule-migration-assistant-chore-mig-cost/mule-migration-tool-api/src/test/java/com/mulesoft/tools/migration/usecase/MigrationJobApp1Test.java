/*
 * Copyright (c) 2020, Mulesoft, LLC. All rights reserved.
 * Use of this source code is governed by a BSD 3-Clause License
 * license that can be found in the LICENSE.txt file.
 */
package com.mulesoft.tools.migration.usecase;

// TODO CHANGE THE NAME OF THIS
public class MigrationJobApp1Test {

  //  private MigrationJob migrationJob;
  //  private Document docRestoreFile;
  //  private String USE_CASE_FILE_PATH = "src/test/resources/mule/apps/usecase01/use-case-01.xml";
  //
  //  private String TASKS_FILE_DIR = "src/test/resources/mule/tasks";
  //
  //  @Before
  //  public void setUp() throws Exception {
  //
  //    migrationJob = new MigrationJob();
  //    migrationJob.setOnErrorStop(Boolean.FALSE);
  //    migrationJob.setFilesDir(USE_CASE_FILE_PATH);
  //    migrationJob.setBackUpProfile(Boolean.FALSE);
  //    docRestoreFile = getDocument(USE_CASE_FILE_PATH);
  //  }
  //
  //  @Test
  //  public void jobWithTasksOnConfigFile() throws Exception {
  //
  //    migrationJob.setFilesDir(USE_CASE_FILE_PATH);
  //    migrationJob.setConfigurationPath(Paths.get(TASKS_FILE_DIR));
  //    migrationJob.execute();
  //  }
  //
  //  @After
  //  public void restoreFileState() throws Exception {
  //    restoreTestDocument(docRestoreFile, USE_CASE_FILE_PATH);
  //  }
}
