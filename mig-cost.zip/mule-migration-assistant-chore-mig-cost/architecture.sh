dot -Tsvg architecture.dot -o architecture.svg
